<?php
/*
 * PHPDeploy
 * Copyright (c) 2011-2012, Christian K�mper <kaemper@ish.de>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @package PHPDeploy
 * @subpackage Component
 * @author Christian K�mper <kaemper@ish.de>
 * @copyrith 2011-2012 Christian K�mper <kaemper@ishde>
 * @license http://www.opensource.org/licenses/bsd-license.php BSD License
 *
 * @since File available since Release 0.0.1
*/
namespace PHPDeploy\Component\Server;
require_once 'Net/SFTP.php';

use PHPDeploy\Component\Server\Exception;


class Ssh extends Server
{

    const NET_SFTP_LOCAL_FILE = 1;

    /**
     * default port to Server
     * can be set through method
     *
     * @var string
     */
    protected $_port = 22;


    /**
     * (non-PHPdoc)
     * @see PHPDeploy\Component\Server.Server::getConnection()
     */
    public function getConnection()
    {
        if (null === $this->_connection) {
            $this->setConnection(new \NET_SFTP($this->getHost(), $this->getPort()));
        }
        return $this->_connection;
    }

    /**
     * @param \NET_SFTP $connection
     */
    public function setConnection(\NET_SFTP $connection)
    {
        $this->_connection = $connection;
    }

    /**
     * (non-PHPdoc)
     * @see PHPDeploy\Component\Server.Server::logIn()
     */
    public function logIn()
    {
        if (!$this->getConnection()->login($this->getUser(), $this->getPassword())) {
            throw new Exception(
            	'Cannot login to Server '
                .$this->getName()
                . ' with User '
                . $this->getUser()
                . ' and pw ' .$this->getPassword()
            );
        }
        $this->_homeDirectory = $this->getConnection()->pwd();
        return true;
    }

    /**
     * @param string $dir
     * @return boolean true|false
     */
    public function doesDirectoryExists($dir)
    {
        return $this->_changeDirectory($dir);
    }

    /**
     * if recursive true createDirectoryRecursive
     *
     * @param string $dir
     * @param boolean $recursive true|false
     * @return boolean true|false
     */
    public function createDirectory($dir, $recursive = false)
    {
        if (false == $recursive) {
            return $this->getConnection()->mkdir($dir);
        }
        return $this->_createDirectoryRecursive($dir);
    }

    public function writeFile($remoteFile, $localFile)
    {
        return $this->getConnection()->put(
            $remoteFile,
            $localFile,
            self::NET_SFTP_LOCAL_FILE
        );
    }


    /**
     * deploys the given project to the server
     *
     * @throws Exception
     * @return boolean true
     */
    public function deploy($output = null)
    {
        if (false == $this->_changeDirectory($this->_homeDirectory)) {
            throw new Exception(
            	'Can not change to Users directory ' . $this->_homeDirectory
            );
        }

        if (false == $this->_createDirectoryRecursive(
            $this->getReleasedir()
            . DIRECTORY_SEPARATOR
            . $this->getReleaseDate())
            ) {
            throw new Exception(
            	'Can not create relase dir ' .$this->getReleaseDate()
            );
        }
        $this->_changeDirectory($this->_homeDirectory);

        if (true == $this->doesDirectoryExists($this->_directory)) {
            if (false == $this->_deleteDirectory($this->_directory)) {
                throw new Exception('can not delete ' . $this->_directory);
            }
        }


        $f = 0;
        foreach ($this->getProject()->getFiles() as $file) {
            $f++;
            $this->_changeDirectory($this->_homeDirectory);

            $file['directory'] = $this->_prependDirectoryToFile(
                $this->getReleasedir()
                . DIRECTORY_SEPARATOR
                . $this->getReleaseDate(),
                $file['directory']
            );

            if (false == $this->_createDirectoryRecursive($file['directory'])) {
                throw new Exception(
            		'Can not create directory ' . $file['directory']
                );
            }

            if (false == $this->writeFile($file['name'], $file['realpath'])) {
                throw new Exception(
            		'Can not write file ' . $file['name'] . 'to server'
                );
            }
            if ($output) {
                $output->write('<comment>.</comment>', false);
                if ($f % 30 == 0) {
                    $output->write('<comment>.</comment>', true);
                }
            }
        }

        $this->_changeDirectory($this->_homeDirectory);
        $command = $this->_createSymbolicLinkCommand($this->getReleaseDate());
        $this->_execute($command);
        $output->write(
        	'<comment>You have totaly deploy '
            . count($this->getProject()->getFiles())
            . ' files </comment>', true, 'comment');

        return true;
    }


    public function rollback($date)
    {

        if (false == $this->_changeDirectory($this->_homeDirectory)) {
            throw new Exception(
            	'Can not change to Users directory ' . $this->_homeDirectory
            );
        }

        if (true == $this->doesDirectoryExists($this->_directory)) {
            if (false == $this->_deleteDirectory($this->_directory)) {
                throw new Exception('can not delete ' . $this->_directory);
            }
        }

        $command = $this->_createSymbolicLinkCommand($date);

        $this->_execute($command);
        if (array_key_exists('0', $this->getConnection()->getErrors())) {
            throw new Exception('can not rollback to release ' .$date);
        }

        return true;
    }


    /**
     *
     * Enter description here ...
     */
    public function getReleases()
    {
        $dirs = $this->_getAllFilesFromDir($this->getReleasedir());

        return $this->_unsetDirectory($dirs, '/\./');
    }



    /**
     * gets details array of all files or dirs in given directory
     * @param string $dir
     * @return array
     */
    protected function _getAllFilesFromDir($dir)
    {
        return $this->getConnection()->nlist($dir);
    }

    /**
     * check for given $haystack in array $dirs
     * unset found dir
     * @param array $dirs
     * @param string $haystack
     * @return array
     */
    protected function _unsetDirectory($dirs, $haystack)
    {
        $releases = array();

        foreach ($dirs as $d => $dir) {
            if (!preg_match($haystack, $dir)) {
                $releases[] = $dir;
            }
        }
        return $releases;
    }

    /**
     *
     * @param string $dir
     * @param string $file
     */
    protected function _prependDirectoryToFile($dir, $file)
    {
        $file = DIRECTORY_SEPARATOR . $dir . $file;
        return $file;
    }

    /**
     * explode dir string by DIRECTORY_SEPARATOR
     * and create each directory
     *
     * @param string $dir
     * @return boolean true|false
     */
    protected function _createDirectoryRecursive($dir)
    {
        $dir = $this->_checkForDS($dir);

        $dirList = explode(DIRECTORY_SEPARATOR, $dir);
        reset($dirList);

        while($dirItem = next($dirList)) {
            if (false == $this->doesDirectoryExists($dirItem)) {
                if (false == $this->createDirectory($dirItem)) {
                    return false;
                }
            }
            $this->_changeDirectory($dirItem);
        }

        return true;
    }

    /**
     *
     * Enter description here ...
     * @param string $dir
     */
    protected function _checkForDS($dir)
    {
        if (0 == strpos($dir, DIRECTORY_SEPARATOR)) {
            return $dir;
        }
        return DIRECTORY_SEPARATOR . $dir;
    }

    /**
     * @param string $dir
     * @return boolean true|false
     */
    protected function _changeDirectory($dir)
    {
        return $this->getConnection()->chdir($dir);
    }

    /**
     * delete given directory from server
     *
     * @param string $dir
     * @return boolean
     */
    protected function _deleteDirectory($dir)
    {
        $deldir = $this->_homeDirectory . $dir;
        $this->_execute('rm -R ' .$deldir);
        $this->_changeDirectory($this->_homeDirectory);
        return !$this->doesDirectoryExists($dir);
    }

    protected function _createSymbolicLinkCommand($date)
    {
        $command = null;

        $command = "ln -s ";

        $virtDir = $this->_homeDirectory . $this->_directory;

        $realDir = $this->_homeDirectory
                 . $this->getReleasedir()
                 . DIRECTORY_SEPARATOR
                 . $date;

        $command .= $realDir ." ". $virtDir;
        return $command;
    }

    /**
     * execute given command on server
     *
     * @param string $command
     * @return boolean
     */
    protected function _execute($command)
    {
        return $this->getConnection()->exec($command);
    }
}