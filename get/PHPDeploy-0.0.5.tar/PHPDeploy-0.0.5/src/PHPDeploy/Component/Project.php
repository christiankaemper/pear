<?php
/*
 * PHPDeploy
 * Copyright (c) 2011-2012, Christian Kaemper <kaemper@ish.de>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @package PHPDeploy
 * @subpackage Component
 * @author Christian K�mper <kaemper@ish.de>
 * @copyrith 2011-2012 Christian K�mper <kaemper@ish.de>
 * @license http://www.opensource.org/licenses/bsd-license.php BSD License
 *
 * @since File available since Release 0.0.1
*/
namespace PHPDeploy\Component;

use RecursiveDirectoryIterator,
    RecursiveIteratorIterator;
class Project
{

    /**
     * @var array
     */
    private $_files = array();

    /**
     * @var string
     */
    private $_path = null;

    /**
     * @var string
     */
    private $_name = null;

    /**
     * @var Symfony\Component\Finder\Finder
     */
    private $_finder = null;

    /**
     * @var string|array
     */
    private $_excludeDirs = null;


    public function getPath()
    {
        return $this->_path;
    }

    public function setPath($path = null)
    {
        if (null == $path) {
            $this->_path = getcwd();
            return;
        }
        if (strpos($path, DIRECTORY_SEPARATOR) != 0) {
            $path = getcwd() . DIRECTORY_SEPARATOR . $path;
        }

        $this->_path = $path;
    }

    public function getName()
    {
        return $this->_name;
    }

    public function setName($name)
    {
        $this->_name = $name;
    }

    /**
     *
     * Enter description here ...
     */
    public function getFiles()
    {
        $this->_readAllFiles();

        return $this->_files;
    }

    public function getFinder()
    {
        if (null === $this->_finder) {
            $this->setFinder(\Symfony\Component\Finder\Finder::create());
        }
        return $this->_finder;
    }

    public function setFinder(\Symfony\Component\Finder\Finder $finder)
    {
        $this->_finder = $finder;
    }


    public function setExcludeDirs($dirs) {
        $this->_excludeDirs = $dirs;
    }

    /**
     *
     * Enter description here ...
     */
    protected function _readAllFiles()
    {
        $this->getFinder()->in($this->getPath());
        if($this->_excludeDirs) {
            $this->getFinder()->exclude($this->_excludeDirs);
        }
        foreach ($this->getFinder()->getIterator() as $filename => $object) {
            if (!$object->isFile()) {
                continue;
            }
            $path = str_ireplace($this->getPath(), '', $filename);
            array_push($this->_files, array(
            	'realpath' => $object->getPathName(),
                'name' => $object->getFilename(),
                                'directory' => DIRECTORY_SEPARATOR . trim(
                               str_ireplace($object->getFilename(), '', $path
                               ),DIRECTORY_SEPARATOR)
            ));

        }
    }

}