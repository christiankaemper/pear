<?php
/*
 * PHPDeploy
 * Copyright (c) 2011-2012, Christian K�mper <kaemper@ish.de>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @package PHPDeploy
 * @subpackage Command
 * @author Christian K�mper <kaemper@ish.de>
 * @copyrith 2011-2012 Christian K�mper <kaemper@ishde>
 * @license http://www.opensource.org/licenses/bsd-license.php BSD License
 *
 * @since File available since Release 0.0.1
*/
namespace PHPDeploy\Command;


use PHPDeploy\Component\Project,
    PHPDeploy\Component\Exception,
    Symfony\Component\Console\Command\Command as SymfonyCommand,
    Symfony\Component\Console\Input\InputInterface,
    Symfony\Component\Console\Output\OutputInterface,
    Symfony\Component\Console\Input\InputArgument,
    Symfony\Component\Console\Input\InputOption;

class Command extends SymfonyCommand
{

    /**
     * @var PHPDeploy\Component\Parser\Parser
     */
    protected $_parser = null;

    /**
     * @var PHPDeploy\Componen\Project
     */
    protected $_project = null;

    /**
     * @var PHPDeploy\Component\Server\Server
     */
    protected $_server = null;


    /**
     * @var string
     */
    protected $_configurationFile = 'phpdeploy.xml';

    /**
     * @var string
     */
    protected $_serverName = null;

    /**
     * @var string
     */
    protected $_databaseName = null;

    /**
     *
     * deployment options
     * @var array
     */
    protected $_options = array();

    /**
     * get condif file for command
     *
     * @return string
     */
    public function getConfigurationFile()
    {
        return $this->_configurationFile;
    }


    /**
     * get parser
     *
     * @return \PHPDeploy\Component\Parser\Parser
     */
    public function getParser()
    {
        if (null === $this->_parser) {
            $suffix = $this->_getConfigurationFileSuffix();
            $this->setParser(
                \PHPDeploy\Component\Parser\Factory::build($suffix)
            );
        }
        return $this->_parser;
    }

    /**
     * set parser
     *
     * @param \PHPDeploy\Component\Parser\Parser $parser
     */
    public function setParser(\PHPDeploy\Component\Parser\Parser $parser)
    {
        $this->_parser = $parser;
    }

    /**
     * get project
     *
	 * @return \PHPDeploy\Component\Project
     */
    public function getProject()
    {
        if (null === $this->_project) {
            $this->setProject(new \PHPDeploy\Component\Project());
        }
        return $this->_project;
    }

    /**
     * set project
     *
     * @param \PHPDeploy\Component\Project $project
     */
    public function setProject(\PHPDeploy\Component\Project $project)
    {
        $this->_project = $project;
    }

    /**
     * get server for command
     * if no server is set we read options and set new with factory class
     *
     * @return \PHPDeploy\Component\Server\Server
     */
    public function getServer()
    {
        if (null === $this->_server) {
            $serverOptions = $this->_getServerOption();
            $serverTyp = $serverOptions['connectiontype'];
            unset($serverOptions['connectiontype']);
            $this->setServer(\PHPDeploy\Component\Server\Factory::build(
                $serverTyp,
                $this->getProject(),
                $serverOptions
            ));
        }
        return $this->_server;
    }

    /**
     * set server
     *
     * @param \PHPDeploy\Component\Server\Server $server
     */
    public function setServer(\PHPDeploy\Component\Server\Server $server)
    {
        $this->_server = $server;
    }


    /**
     * (non-PHPdoc)
     * @see Symfony\Component\Console\Command.Command::execute()
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->_writeWelcomeMessage($output);

        $this->_initConfigurationFile($input);

        if ($serverName = $input->getOption('server')) {
            $this->_serverName = $serverName;
        }

        if (false == is_array(
            $data = $this->getParser()->load($this->_configurationFile))
            ) {
            $this->_options = $this->getParser()->parse($data);
        } else {
           $this->_options = $data;
        }

        $this->_initServer();
        $this->_initProject();

    }


    protected function _writeWelcomeMessage(OutputInterface $output)
    {
        $output->writeln(
        	"<info>Welcome to PHPDeploy Version "
            . PHPDEPLOY_VERSION
            . " by Christian Kaemper\n\n</info>"
        );
    }

    /**
     * check if config file is set in options
     *
     * @param string $input
     *
     * @return string
     */
    protected function _initConfigurationFile($input)
    {
        if ($fileName = $input->getOption('config')) {

            if (strpos($fileName, DIRECTORY_SEPARATOR) != 0) {
                $file = getcwd() . DIRECTORY_SEPARATOR . $fileName;
            } else {
                $file = $fileName;
            }

            $this->_configurationFile = $file;
        }
        $this->_doesConfigFileExists($this->_configurationFile);
    }

    /**
     * get extension from configuration file
     *
     * @return string
     */
    protected function _getConfigurationFileSuffix()
    {
        $pathInfo = pathinfo($this->_configurationFile);
        return ucfirst($pathInfo['extension']);
    }

    protected function _doesConfigFileExists($file)
    {
        if (!is_readable($file)) {
            throw new \PHPDeploy\Component\Exception(
            	'Configuration file does not exists or is not readable ' . $file
            );
        }
    }

    /**
     *
     * Enter description here ...
     *
     * @return array
     */
    protected function _getServerOption()
    {
        foreach ($this->_options['server'] as $server) {
            if ($server['name'] == $this->_serverName) {
                return $server['name'];
            }
        }
        return $this->_options['server'][0];
    }

    /**
     * init Component\Project
     *
     * @param OutputInterface $output
     * @throws Exception
     */
    protected function _initProject()
    {
        if (false == array_key_exists('server', $this->_options)) {
            throw new Exception('No Server defined in config File');
        }

        $this->getProject()->setName($this->_options['project']['name']);
        $this->getProject()->setPath($this->_options['project']['path']);
        if (array_key_exists('exclude_dirs', $this->_options['project'])) {
            $this->getProject()->setExcludeDirs(
               $this->_options['project']['exclude_dirs']
            );
        }


    }

    /**
     *
     * init Component\Server\Server
     *
     * @param OutputInterface $output
     * @throws Exception
     */
    protected function _initServer()
    {
        if (false == array_key_exists('server', $this->_options)) {
            throw new Exception('No Server defined in config File');
        }

        $this->getServer();
    }
}
