<?php
/*
 * PHPDeploy
 * Copyright (c) 2011-2012, Christian K�mper <kaemper@ish.de>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @package PHPDeploy
 * @subpackage Command
 * @author Christian K�mper <kaemper@ish.de>
 * @copyrith 2011-2012 Christian K�mper <kaemper@ishde>
 * @license http://www.opensource.org/licenses/bsd-license.php BSD License
 *
 * @since File available since Release 0.0.3
*/
namespace PHPDeploy\Command;

use PHPDeploy\Component\Exception;

use Symfony\Component\Console\Input\InputInterface,
    Symfony\Component\Console\Output\OutputInterface,
    Symfony\Component\Console\Input\InputArgument,
    Symfony\Component\Console\Input\InputOption;

class Rollback extends Command
{
    const COMMANDNAME = 'rollback';

    protected function configure()
    {
        $this->setName(self::COMMANDNAME)
             ->setDescription('Rollback your Application')
             ->addArgument('date', InputArgument::REQUIRED, 'Date String or ID of the Release to rollback to')
             ->addOption('config', null, InputOption::VALUE_OPTIONAL, 'The path to a PHPDeploy configuration file.')
             ->addOption('server', null, InputOption::VALUE_OPTIONAL, 'Server name to deploy to')
             ->addOption('database', null, InputOption::VALUE_OPTIONAL, 'Database to use for deployment');
    }

    /**
     * (non-PHPdoc)
     * @see Symfony\Component\Console\Command.Command::execute()
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {

        parent::execute($input, $output);

        $date = $input->getArgument('date');
        $this->getServer()->getConnection();
        $this->getServer()->logIn();

        $output->writeln(
        	"<info>You are rollback to your "
            . $this->getServer()->getName()
            . " Server</info>"
        );


        $releaseDate = $this->_checkRollbackDate($date);
        $this->getServer()->setReleaseDate($releaseDate);

        $output->writeln(
        	"<info>You are rollback your "
            . $this->getProject()->getName() . " Project to release "
            . $releaseDate . "</info>"
        );

        $this->getServer()->rollback($releaseDate);

    }

    /**
     *
     * Enter description here ...
     * @param unknown_type $date
     */
    protected function _checkRollbackDate($date)
    {

        $releases = $this->getServer()->getReleases();
        $releases = array_flip($releases);

        if (strlen($date) > 1) {
            if (!array_key_exists($date, $releases)) {
                throw new Exception('the given release does not exists ' .$date);
            }
            return $date;
        }


        foreach ($releases as $k => $release) {
            if ($release == $date) {
                return $k;
            }
        }
        throw new Exception('the given release ID does not exists ' .$date);
    }
}
